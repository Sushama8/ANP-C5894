/**
 * 
 */
/**
 * 
 */
module JDBCDemo {
	requires java.sql;
}