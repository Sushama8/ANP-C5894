package com.anudip.springdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication

public class SpringBootCrud1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCrud1Application.class, args);
	}

}
