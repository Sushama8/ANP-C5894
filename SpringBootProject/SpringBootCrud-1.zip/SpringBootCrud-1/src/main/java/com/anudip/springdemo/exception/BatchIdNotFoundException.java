package com.anudip.springdemo.exception;


public class BatchIdNotFoundException extends RuntimeException 
{
	public BatchIdNotFoundException(String message) 
	{
		super(message);
		
	}

	

}
