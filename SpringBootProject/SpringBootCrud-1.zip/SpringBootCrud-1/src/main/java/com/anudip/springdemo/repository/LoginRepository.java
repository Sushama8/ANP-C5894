package com.anudip.springdemo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.anudip.springdemo.entity.Login;

public interface LoginRepository extends JpaRepository<Login, Integer>{
	
	public Login findByUserNameAndPassword(String userName, String Password);
}