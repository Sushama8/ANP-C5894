package com.anudip.springdemo.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity

@Data

@NoArgsConstructor

@AllArgsConstructor

public class Department 
{
	@Id
	private int did;
	@Column(length=25,nullable=true)
	@NotBlank(message="Department name can't be blank")
	private String dname;
	@Column(length=25,nullable=true)
	private String dHod;
	@Column(length=25,nullable=true)
	@NotNull(message="kindly mention no. of employee")
	private int noOfEmpl;
	
	/*public int getDid() {
		return did;
	}
	public void setDid(int did) {
		this.did = did;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getdHod() {
		return dHod;
	}
	public void setdHod(String dHod) {
		this.dHod = dHod;
	}
	public int getNoOfEmpl() {
		return noOfEmpl;
	}
	public void setNoOfEmpl(int noOfEmpl) {
		this.noOfEmpl = noOfEmpl;
	}
	
	*/
	/*@OneToMany(mappedBy="department", fetch = FetchType.EAGER, cascade= CascadeType.ALL)
	@JsonManagedReference
	List<Teacher> teacherlist;*/

}
