package com.anudip.springdemo.service;
import java.util.List;

import org.hibernate.engine.jdbc.batch.spi.Batch;

import jakarta.validation.Valid;

public interface BatchService
{

	//method for saving teacher details in db table
	Batch addBatch(com.anudip.springdemo.entity.Batch batch);
	
	//method to fetch teacher detail based on tid from db table
	Batch getBatchDetail(int bid);
	
	//method to modify teacher detail based on tid from db table
	Batch updateBatchDetail(Batch batch, int bid);
	
	//method to remove teacher detail based on tid from db table
	void deleteBatchDetail(int bid);

	com.anudip.springdemo.entity.Batch addBatches(com.anudip.springdemo.entity.Batch batch);

	com.anudip.springdemo.entity.Batch getBatchDetails(int bid);

	List<com.anudip.springdemo.entity.Batch> getAllBatches1();

	List<com.anudip.springdemo.entity.Batch> getAllBatches();
}
