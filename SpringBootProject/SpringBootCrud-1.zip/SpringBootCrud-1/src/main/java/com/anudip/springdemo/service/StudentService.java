package com.anudip.springdemo.service;

import java.util.List;

import com.anudip.springdemo.entity.Student;
import com.anudip.springdemo.entity.Teacher;

public interface StudentService 
{
	Student addStudetns(Student student);
	
	Student getStudentDetails(int sid);
	
	Student UpdateStudentDetails(Student student, int sid);
	
	void deleteStudentDetails(int sid);
	
	List<Student> getAllStudents();
	

}
