package com.anudip.springdemo.serviceimpl;

import java.util.List;
import java.util.ArrayList;
//import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.anudip.springdemo.entity.Teacher;
import com.anudip.springdemo.exception.TeacherIdNotFoundException;
import com.anudip.springdemo.repository.TeacherRepository;
import com.anudip.springdemo.service.TeacherService;

//business logic(CRUD Implementation) of entity teacher
@Service
public class TeacherServiceImpl implements TeacherService
{
	@Autowired
	TeacherRepository trepo;

	//use save() of Jpa repository for saving details
	@Override
	public Teacher addTeacher(Teacher teacher) 
	{
		return trepo.save(teacher);
		
		
	}

	@Override
	public Teacher getTeacherdetails(int tid) 
	{
		
		return trepo.findById(tid).orElseThrow(()-> new TeacherIdNotFoundException("Teacher Id is not correct"));
	}

	@Override
	public Teacher UpdateTeacherdetails(Teacher teacher, int tid)
	{
		Teacher updatedTeacher = trepo.findById(tid).
		         orElseThrow(()-> new TeacherIdNotFoundException("Teacher Id is not correct"));

		updatedTeacher.setPhone(teacher.getPhone());
		updatedTeacher.setDesignation(teacher.getDesignation());
		
		trepo.save(updatedTeacher); //saving updated details 
			return updatedTeacher; 
		
	}

	@Override
	public void DeleteTeacherdetails(int tid) 
	{
		trepo.findById(tid).
		orElseThrow(()-> new TeacherIdNotFoundException("Teacher Id is not correct"));
	    trepo.deleteById(tid);
		
	}
	
	@Override
    public List<Teacher> getAllTeachers() 
	{
        return trepo.findAll(); // Retrieve all teacher records from the repository
    }

	@Override
	public Teacher getTeacherByPhone(long phone) {
        return trepo.findById((int) phone).orElseThrow();
    }

	@Override
	public List<Teacher> getTeacherByName(String tname) {
		// TODO Auto-generated method stub
		return trepo.findAll();
	}

	@Override
	public List<Teacher> getTeacherDesignation(String designation) {
		// TODO Auto-generated method stub
		return trepo.findByDesignation(designation);
	}
	
	
	
}
