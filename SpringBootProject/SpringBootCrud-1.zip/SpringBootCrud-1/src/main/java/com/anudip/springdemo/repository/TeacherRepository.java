package com.anudip.springdemo.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.anudip.springdemo.entity.Teacher;

//Jpa repository for CRUD method
public interface TeacherRepository extends JpaRepository<Teacher, Integer>{

	//List<Teacher> findByDesignation(String designation);

	List<Teacher> findByDesignation(String designation);

}
