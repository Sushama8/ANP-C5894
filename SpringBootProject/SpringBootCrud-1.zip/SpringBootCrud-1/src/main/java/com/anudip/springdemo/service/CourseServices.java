package com.anudip.springdemo.service;

import java.util.List;

import com.anudip.springdemo.entity.Course;

public interface CourseServices 
{
	Course addcourses(Course course);
	Course getCourseDetails(int cid);
	List<Course> getAllCourse();

}
