package com.anudip.springdemo.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import com.anudip.springdemo.entity.Batch;

public interface BatchRepository extends JpaRepository<Batch, Integer>
{

}
