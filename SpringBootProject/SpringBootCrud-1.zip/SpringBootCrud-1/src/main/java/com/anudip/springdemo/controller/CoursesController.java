package com.anudip.springdemo.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.anudip.springdemo.entity.Course;
import com.anudip.springdemo.service.CourseServices;

import jakarta.validation.Valid;

@RestController
public class CoursesController 
{
	@Autowired
	CourseServices cs;
	
	@PostMapping("/Course/addCourse")
	public ResponseEntity<Course> saveCourse(@Valid @RequestBody Course course )
	{
		return new ResponseEntity<Course>(cs.addcourses(course), HttpStatus.OK);
		
	}
	
	@GetMapping("/Course/getCourseDetails/{cid}")
	public ResponseEntity<Course> getCourse(@PathVariable("cid") int cid)
	{
		return new ResponseEntity<Course>(cs.getCourseDetails(cid), HttpStatus.OK);
	}
	
	@GetMapping("/Course/getAllCourses")
	public ResponseEntity<List<Course>> getAllCourses()
	{
		List<Course> course=cs.getAllCourse();
		return new ResponseEntity<List<Course>> (course,HttpStatus.OK);
		
	}
}
