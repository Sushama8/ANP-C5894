package com.anudip.springdemo.service;
//import com.anudip.springdemo.service.LoginService;


import org.springframework.stereotype.Service;

import com.anudip.springdemo.entity.Login;

@Service
public interface LoginService {
	
	public Login loginUser(String userName, String password);

}