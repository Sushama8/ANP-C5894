package com.anudip.springdemo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data

public class Login {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int uid;;
	
	@Column(length=8, nullable = false)
	private String userName;
	
	@Column(length=10, nullable = false)
	private String password;
	
	
	
	
}