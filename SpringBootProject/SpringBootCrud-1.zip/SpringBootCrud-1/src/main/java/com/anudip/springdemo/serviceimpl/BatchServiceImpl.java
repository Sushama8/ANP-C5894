package com.anudip.springdemo.serviceimpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.springdemo.entity.Batch;
import com.anudip.springdemo.exception.BatchIdNotFoundException;
import com.anudip.springdemo.repository.BatchRepository;
import com.anudip.springdemo.service.BatchService;
@Service
public class BatchServiceImpl implements BatchService
{
	@Autowired
	BatchRepository br;

	@Override
	public Batch addBatches(Batch batch) 
	{
		
		return br.save(batch) ;
	}

	@Override
	public Batch getBatchDetails(int bid) 
	{
		
		return br.findById(bid).orElseThrow(()-> new BatchIdNotFoundException("Batch id is not correct"));
	}

	@Override
	public List<Batch> getAllBatches() 
	{
		
		return br.findAll();
	}

	@Override
	public org.hibernate.engine.jdbc.batch.spi.Batch addBatch(Batch batch) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public org.hibernate.engine.jdbc.batch.spi.Batch getBatchDetail(int bid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public org.hibernate.engine.jdbc.batch.spi.Batch updateBatchDetail(org.hibernate.engine.jdbc.batch.spi.Batch batch,
			int bid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteBatchDetail(int bid) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Batch> getAllBatches1() {
		// TODO Auto-generated method stub
		return null;
	}

}
