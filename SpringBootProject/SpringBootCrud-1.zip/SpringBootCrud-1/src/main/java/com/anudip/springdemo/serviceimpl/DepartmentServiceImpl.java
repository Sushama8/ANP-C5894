package com.anudip.springdemo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.springdemo.entity.Department;
import com.anudip.springdemo.exception.DepartmentIdNotFoundException;
import com.anudip.springdemo.repository.DepartmentRepository;
import com.anudip.springdemo.service.DepartmentServices;

@Service
public class DepartmentServiceImpl implements DepartmentServices
{
	@Autowired
	DepartmentRepository drepo;

	@Override
	public Department addDepartment(Department department) 
	{
		
		return drepo.save(department);
	}

	@Override
	public Department getDepartmentDetails(int did) 
	{
		
		return drepo.findById(did).orElseThrow(()-> new DepartmentIdNotFoundException("Department id is not correct"));
		
	}

	@Override
	public Department UpdateDepartmentDetails(Department department, int did) 
	{
		
		Department updateddepartment= drepo.findById(did).orElseThrow(()-> new DepartmentIdNotFoundException("Department id is not correct"));
		
		updateddepartment.setDname(department.getDname());
		updateddepartment.setDHod(department.getDHod());
		drepo.save(updateddepartment);

		return updateddepartment;
	}

	@Override
	public List<Department> getAllDepartments() 
	{
		
		return drepo.findAll();
	}
	

}
