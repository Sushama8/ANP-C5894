package com.anudip.springdemo.service;

import java.util.List;

import com.anudip.springdemo.entity.Department;


public interface DepartmentServices 
{
    Department addDepartment(Department department);
	
    Department getDepartmentDetails(int did);
	
    Department UpdateDepartmentDetails(Department department, int did);
	
	
	
	List<Department> getAllDepartments();

}
