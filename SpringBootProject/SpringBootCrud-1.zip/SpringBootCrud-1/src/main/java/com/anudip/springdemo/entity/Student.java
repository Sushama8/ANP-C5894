package com.anudip.springdemo.entity;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Student 
{
	@Id
	private int sid;
	@Column(length=25, nullable=false)
	@NotBlank(message="Student name can't be blank")
	private String sname;
	@Column(length=25)
	private String lname;
	@Column(length=25,nullable=false,unique=true)
	@NotNull(message="Student phone can't be blank")
	private long sphone;
	@Column(length=25, nullable=false, unique=true)
	@NotBlank(message="Student email can't be blank")
	@Email(message="email is not correct")
	private String semail;
	@Column(length=25, nullable=false)
	@NotBlank(message="Student address can't be blank")
	private String saddr;
	@Column(length=25, nullable=false)
	@NotBlank(message="Student education can't be blank")
	private String seduc;
	
	/*public int getSid() {
		return sid;
	}
	public void setSid(int sid) {
		this.sid = sid;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public long getSphone() {
		return sphone;
	}
	public void setSphone(long sphone) {
		this.sphone = sphone;
	}
	public String getSemail() {
		return semail;
	}
	public void setSemail(String semail) {
		this.semail = semail;
	}
	public String getSaddr() {
		return saddr;
	}
	public void setSaddr(String saddr) {
		this.saddr = saddr;
	}
	public String getSeduc() {
		return seduc;
	}
	public void setSeduc(String seduc) {
		this.seduc = seduc;
	}
	*/
	
	@OneToOne(fetch=FetchType.EAGER,cascade=CascadeType.ALL)
	@JoinColumn(name="courseId", referencedColumnName = "cid")
	@JsonBackReference
	private Course course;
	

}
