package com.anudip.springdemo.serviceimpl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anudip.springdemo.entity.Student;
import com.anudip.springdemo.exception.StudentIdNotFoundException;
import com.anudip.springdemo.repository.StudentRepository;
import com.anudip.springdemo.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService
{
	@Autowired
	StudentRepository srepo;

	@Override
	public Student addStudetns(Student student) 
	{
		
		return srepo.save(student);
	}

	@Override
	public Student getStudentDetails(int sid) 
	{
		
		return srepo.findById(sid).orElseThrow(()-> new StudentIdNotFoundException("Student Id is not correct"));
	}

	@Override
	public Student UpdateStudentDetails(Student student, int sid) 
	{
		Student updatedStudent = srepo.findById(sid).orElseThrow(()-> new StudentIdNotFoundException("Student Id is not correct"));
		
		updatedStudent.setSphone(student.getSphone());
		updatedStudent.setSaddr(student.getSaddr());
		srepo.save(updatedStudent);
		
		return updatedStudent;
	}

	@Override
	public void deleteStudentDetails(int sid) 
	{
		srepo.findById(sid).orElseThrow(()-> new StudentIdNotFoundException("Student Id is not correct"));
		srepo.deleteById(sid);
	}
	
	@Override
	public List<Student> getAllStudents()
	{
		return srepo.findAll();
		
	}

}
